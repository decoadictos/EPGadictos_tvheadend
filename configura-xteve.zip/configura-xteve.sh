#!/bin/bash

# comprobamos que se pasan dos argumentos al script
if [ $# != 2 ]; then
    echo "Uso: $0 param1 [param2]"
    echo "* param1: ejemplo: 192.168.1.150"
    echo "* param2: ejemplo: usuario"
    exit 1
fi

# anti jlu mod
if [ $2 = "root" ]; then
	echo "root no puede ser el usuario"
	exit 1 
fi

# comprobamos root, necesario para activar el servicio
if [ $(id -u) != "0" ]; then
    echo "No eres root, por favor corre el script con sudo"
    exit 1
fi

HOME='/home/'$2'' # cogemos la segunada variable pasada por shell para nombre de usuario
HOST=$(ip -4 addr show lo | grep -oP "(?<=inet ).*(?=/)") # nos da la ip de la máquina que se está ejecutando
echo "la ip del server de xteve es $HOST"

#comprobamos si xteve está corriendo
ps cax | grep xteve > /dev/null
if [ $? -eq 0 ]; then
	echo "xteve is running."
	systemctl stop xteve.service
	rm -fr $HOME/.xteve
	rm -fr $HOME/bin
	rm -f $HOME/vuuno4k.m3u8
	rm -fr /tmp/xteve
fi

#creamos la carpeta donde vamos a poner el binario de xteve
if [ ! -d $HOME/bin ]; then
	mkdir -p $HOME/bin
fi

unzip xteve.zip -d $HOME # extraemos el zip en home

#según la arquitectura descar amd64 o arm64
case "`uname -m`" in
	x86_64|amd64|i?86)
		echo "X64"
		wget https://xteve.de/download/xteve_2_linux_amd64.zip
		unzip xteve_2_linux_amd64.zip -d $HOME/bin/
		rm -f xteve_2_linux_amd64.zip
	;;
	arm*|aarch64)
		wget https://xteve.de/download/xteve_2_linux_arm64.zip
		unzip xteve_2_linux_arm64.zip -d $HOME/bin/
		rm -f xteve_2_linux_arm64.zip
		echo "ARM"
	;;
esac

#añade la ip a al m3u
find $HOME -name 'vuuno4k.m3u8' -type f -exec sed -i 's/xxx.xxx.xxx.xxx/'$1'/g' {} +
# ponemos la ip del deco en todos los archivos dentro de .xteve
find $HOME/.xteve -type f -exec sed -i 's/xxx.xxx.xxx.xxx/'$1'/g' {} +
# ponemos nuestro nombre de usuario en todos los archivos dentro de .xteve
find $HOME/.xteve -type f -exec sed -i 's/usuario/'$2'/g' {} +
# ponemos la ip donde se encuentra xteve en el unico archivo que lo utiliza
find $HOME/.xteve -type f -exec sed -i 's/192.168.1.150/'$HOST'/g' {} +

# creamos el archivo de servicio de xteve
cat > /etc/systemd/system/xteve.service <<EOF
[Unit]
Description=xTeVe Service
Wants=network.target
After=network.target

[Service]
Type=simple
ExecStart=$HOME/bin/xteve 
ExecStop=/bin/kill -TERM $MAINPID
ExecReload=/bin/kill -HUP $MAINPID
KillMode=process
Restart=always
RestartSec=15

User=$2
Group=$2
[Install]
WantedBy=multi-user.target
EOF

# arreglamos los permisos de xteve
chown -R $2:$2 $HOME/.xteve
chown -R $2:$2 $HOME/bin
chown $2:$2 $HOME/vuuno4k.m3u8

# activamos xteve en el sistema
sudo systemctl daemon-reload
sudo systemctl enable xteve.service
sudo systemctl start xteve.service

# eliminamos residuos
rm -f xteve.zip
rm -f configura-xteve.sh
exit 0
